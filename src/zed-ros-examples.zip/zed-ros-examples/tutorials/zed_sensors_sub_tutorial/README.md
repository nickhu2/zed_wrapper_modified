# Sensor Data Tutorial

In this tutorial you will learn how to write a simple node that subscribes to sensor data messages from ZED2 or ZED-M and print the values to console.

The complete documentation is available on the [Stereolabs website](https://www.stereolabs.com/docs/ros/sensors-data/#sensor-data-subscribing-in-c)


